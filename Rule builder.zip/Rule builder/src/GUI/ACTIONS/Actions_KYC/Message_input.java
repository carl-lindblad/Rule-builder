package GUI.ACTIONS.Actions_KYC;

import javax.swing.*;

public class Message_input {
    private JPanel messagePanel;
    private JComboBox levelComboBox;
    private JTextArea messagetextArea;



}
