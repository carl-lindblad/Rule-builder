import GUI.StartPage;
import com.frameBuilder;

public class Main {
    public static void main(String argv[]) {
        frameBuilder test = new frameBuilder();
        StartPage open = new StartPage();

        StartPage b = new StartPage();
        b.buildStartPage();
    }
}
